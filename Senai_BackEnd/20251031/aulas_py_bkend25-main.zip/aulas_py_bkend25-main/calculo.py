def dobro(numero):
    return int(numero) * 2

def triplo(num):
    return int(num) * 3