# import calculo
# importando de outro jeito:

import opcoes_de_escolha

# print("ola mundo agora no vscode \n")
# print("programa dos calculos")
# print("-" * 50)

# x = input("Digite o numero e vou dizer o dobro:")



opcoes_de_escolha.operacoes()


